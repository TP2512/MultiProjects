from setuptools import setup, find_packages

setup(name='Graph_Processing', version='1.0', packages=find_packages())
